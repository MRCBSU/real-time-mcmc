library(readr)
library(tidyr)
library(lubridate)
library(dplyr)

all.dat <- bind_rows(## read_tsv("deaths20200407_London.txt", col_names = F) %>%
                     ## mutate(Dataset = lubridate::as_date("20200407")),
                     ## read_tsv("deaths20200407_Outside_London.txt", col_names = F) %>%
                     ## mutate(Dataset = lubridate::as_date("20200407")),
                     ## read_tsv("deaths20200408_London.txt", col_names = F) %>%
                     ## mutate(Dataset = lubridate::as_date("20200408")),
                     ## read_tsv("deaths20200408_Outside_London.txt", col_names = F) %>%
                     ## mutate(Dataset = lubridate::as_date("20200408")),
                     read_tsv("deaths20200412_London.txt", col_names = F) %>%
                     mutate(Dataset = lubridate::as_date("20200412")),
                     read_tsv("deaths20200412_Outside_London.txt", col_names = F) %>%
                     mutate(Dataset = lubridate::as_date("20200412"))
                     )

all.dat <- all.dat %>%
    group_by(X1, Dataset) %>%
    summarise(Count = sum(X2))

library(ggplot2)

ggv <- ggplot(all.dat, aes(x = X1, y = Count, colour = factor(Dataset), group = Dataset)) +
    geom_line() +
    geom_point(size = 1.5) +
    xlab("Date of death") +
    ylab("Number of new deaths") +
    labs(colour = "Dataset") +
    theme(axis.title = element_text(size = 16),
          axis.text = element_text(size = 14),
          legend.text = element_text(size = 14),
          legend.title = element_text(size = 16))
ggv
